import os
import sys
import random
import math
import re
import time
import numpy as np
import tensorflow as tf
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Root directory of the project
ROOT_DIR = "C:\\Users\\LIAL\Desktop\\Mask_RCNN-master"  # 最好用绝对路径

# Import Mask RCNN
sys.path.append(ROOT_DIR)  # To find local version of the library
from mrcnn import utils
from mrcnn import visualize
from mrcnn.visualize import display_images
import mrcnn.model as modellib
from mrcnn.model import log

from samples.balloon import balloon

# Directory to save logs and trained model
MODEL_DIR = os.path.join(ROOT_DIR, "logs")

# Path to Ballon trained weights
# You can download this file from the Releases page
# https://github.com/matterport/Mask_RCNN/releases
BALLON_WEIGHTS_PATH_BETTER =  "C:\\Users\\LIAL\\Desktop\\Mask_RCNN-master\\mask_rcnn_container_0043.h5"# TODO: update this path
BALLON_WEIGHTS_PATH =  "C:\\Users\\LIAL\\Desktop\\Mask_RCNN-master\\new-mask_rcnn_container_0030.h5"# TODO: update this path
config = balloon.BalloonConfig()
BALLOON_DIR = "C:\\Users\\LIAL\\Desktop\\Mask_RCNN-master\\dataset\\container"


# Override the training configurations with a few
# changes for inferencing.
class InferenceConfig(config.__class__):
    # Run detection on one image at a time
    GPU_COUNT = 1
    IMAGES_PER_GPU = 1


config = InferenceConfig()
config.display()

# Device to load the neural network on.
# Useful if you're training a model on the same
# machine, in which case use CPU and leave the
# GPU for training.
DEVICE = "/cpu:0"  # /cpu:0 or /gpu:0

# Inspect the model in training or inference modes
# values: 'inference' or 'training'
# TODO: code for 'training' test mode not ready yet
TEST_MODE = "inference"


def get_ax(rows=1, cols=1, size=16):
    """Return a Matplotlib Axes array to be used in
    all visualizations in the notebook. Provide a
    central point to control graph sizes.

    Adjust the size attribute to control how big to render images
    """
    _, ax = plt.subplots(rows, cols, figsize=(size * cols, size * rows))
    return ax


# Load validation dataset
dataset = balloon.BalloonDataset()
dataset.load_balloon(BALLOON_DIR, "val")  # detect所用图片

# Must call before using the dataset
dataset.prepare()

print("Images: {}\nClasses: {}".format(len(dataset.image_ids), dataset.class_names))



def det(modelDir):
    # Create model in inference mode
    with tf.device(DEVICE):
        model = modellib.MaskRCNN(mode="inference", model_dir=MODEL_DIR,
                                  config=config)


    # Set path to balloon weights file

    # Download file from the Releases page and set its path
    # https://github.com/matterport/Mask_RCNN/releases
    # weights_path = "/path/to/mask_rcnn_balloon.h5"

    # Or, load the last model you trained
    weights_path = BALLON_WEIGHTS_PATH
    weights_path_better = BALLON_WEIGHTS_PATH_BETTER
    # Load weights
    print("Loading weights ", weights_path)
    model.load_weights(modelDir, by_name=True)



    height, width = image.shape[:2]

    print(height)
    print(width)
    print("image ID: {}.{} ({}) {}".format(info["source"], info["id"], image_id,
                                           dataset.image_reference(image_id)))



    # Run object detection
    results = model.detect([image], verbose=1)


    # Display results
    #ax = get_ax(1)
    r = results[0]
    # testImage = visualize.display_instances(image, r['rois'], r['masks'], r['class_ids'],
    #                             dataset.class_names, r['scores'], ax=ax,
    #                             title="Predictions")
    return results[0],image


    # results_better = model.detect([image], verbose=1)
    # ax_better = get_ax(1)
    # r_better = results[0]
    # visualize.display_instances(image, r_better['rois'], r_better['masks'], r_better['class_ids'],
    #                             dataset.class_names, r_better['scores'], ax=ax_better,
    #                             title="Predictions")
    #
    # visualize.display_differences(image, gt_bbox, gt_class_id, gt_mask, r['rois'], r['class_ids'],r['scores'],r['masks'],
    #                               dataset.class_names,ax=ax)
    # log("gt_class_id", gt_class_id)
    # log("gt_bbox", gt_bbox)
    # log("gt_mask", gt_mask)

    # # Compute VOC-Style mAP @ IoU=0.5
    # # Running on 10 images. Increase for better accuracy.
    # image_ids = np.random.choice(dataset.image_ids, 10)
    # APs = []
    # for image_id in image_ids:
    #     # Load image and ground truth data
    #     image, image_meta, gt_class_id, gt_bbox, gt_mask = \
    #         modellib.load_image_gt(dataset, config,
    #                                image_id, use_mini_mask=False)
    #     molded_images = np.expand_dims(modellib.mold_image(image, config), 0)
    #     # Run object detection
    #     results = model.detect([image], verbose=0)
    #     r = results[0]
    #     # Compute AP
    #     AP, precisions, recalls, overlaps = \
    #         utils.compute_ap(gt_bbox, gt_class_id, gt_mask,
    #                          r["rois"], r["class_ids"], r["scores"], r['masks'])
    #     APs.append(AP)
    #
    # #print("mAP: ", np.mean(APs))
image_id = random.choice(dataset.image_ids)
image, image_meta, gt_class_id, gt_bbox, gt_mask =\
        modellib.load_image_gt(dataset, config, image_id, use_mini_mask=False)
info = dataset.image_info[image_id]

r1,image = det(BALLON_WEIGHTS_PATH_BETTER)

r2,image = det(BALLON_WEIGHTS_PATH)

testImage = visualize.display_2_instances(image, r1['rois'], r1['masks'], r1['class_ids'],r2['rois'], r2['masks'], r2['class_ids'],
                                dataset.class_names, r1['scores'],r2['scores'],
                                title="Predictions")

